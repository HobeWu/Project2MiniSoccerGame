package model.players;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class PlayerCollection implements Iterable<GamePlayer> {
	protected List<GamePlayer> playList;

	
	public PlayerCollection() {
		this.playList = new ArrayList<GamePlayer>();
	
	}
	public void add(GamePlayer e) {
		this.playList.add(e);
	
	}
	public void remove(GamePlayer e) {
		this.playList.remove(e);
		
	}
	public int size(){
	       return this.playList.size();
	}
//	public void sort() {
//		// TODO Auto-generated method stub
//		
//	}
	@Override
    public Iterator<GamePlayer> iterator() {
        return playList.iterator();
        
	}

	public GamePlayer get(String string) {
		for (GamePlayer player : playList) {
			if(player.getPlayerName().equalsIgnoreCase(string))
				return player;
		}
		return null;
	}
	public void sort() {
		// TODO Auto-generated method stub
		
	}

}
