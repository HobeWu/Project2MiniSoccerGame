package model.players;

public class PlayerStatistics {
	public Integer state;
	public PlayerStatistics() {
		this.state = new Integer(0);
	}
	public void setStatistics(Integer newStatistics) {
		// TODO Auto-generated method stub
		this.state = newStatistics ;
		
	}

	public Integer getStatistics() {
		// TODO Auto-generated method stub
	
		return state;
	}
	@Override
	public String toString() {
		return this.state.toString();
		
	}

}
